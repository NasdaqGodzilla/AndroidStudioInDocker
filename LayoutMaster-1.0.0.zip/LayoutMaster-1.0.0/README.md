# Layout Master

相关文章介绍 ：[https://www.jianshu.com/p/b06baa73e099](https://www.jianshu.com/p/b06baa73e099)

插件基于Layout Inspector，强化了这个工具，故取名Layout Master。

使用方式同Layout Inspector，呼出Android Studio或Idea的Action面板，输入Layout Master点击即可

![](https://github.com/wuapnjie/LayoutMaster/blob/master/images/pic1.png)

插件效果如下

![LayoutMaster](https://github.com/wuapnjie/LayoutMaster/blob/master/images/pic2.gif)
